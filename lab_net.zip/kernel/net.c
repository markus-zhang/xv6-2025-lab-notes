#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "fs.h"
#include "sleeplock.h"
#include "file.h"
#include "net.h"

// xv6's ethernet and IP addresses
static uint8 local_mac[ETHADDR_LEN] = { 0x52, 0x54, 0x00, 0x12, 0x34, 0x56 };
static uint32 local_ip = MAKE_IP_ADDR(10, 0, 2, 15);

// qemu host's ethernet address.
static uint8 host_mac[ETHADDR_LEN] = { 0x52, 0x55, 0x0a, 0x00, 0x02, 0x02 };

static struct spinlock netlock;

struct packet {
  char* buf;
  int len;  // length of buffer
};

struct bindqueue{
  struct spinlock queuelock;
  int port;
  int count;
  struct packet q[16];
};

// I don't know how many ports are there in the test, let's assume there are 16 different ports
struct bindqueue bq[16];
int bqcount = 0;

void
netinit(void)
{
  initlock(&netlock, "netlock");
  // Initiate bq
  for (int i = 0; i < 16; i++)
  {
    bq[i].port = 0;
    bq[i].count = 0;
    initlock(&bq[i].queuelock, "queuelock");
  }
}


//
// bind(int port)
// prepare to receive UDP packets address to the port,
// i.e. allocate any queues &c needed.
//
uint64
sys_bind(void)
{
  int port;

  argint(0, &port);

  for (int i = 0; i < 16; i++)
  {
    if (port == bq[i].port)
    {
      return 0;
    }
  }

    // Build a new one if there is space
  if (bqcount == 16)
  {
    printf("sys_bind: No space to bind port %d\n", port);
    return -1;
  }
  // Space is allocated on stack already, so just need to set the port
  bq[bqcount].port = port;
  bq[bqcount].count = 0;  // Redundant but clear it again
  bqcount++;
  return 0;
}

//
// unbind(int port)
// release any resources previously created by bind(port);
// from now on UDP packets addressed to port should be dropped.
//
uint64
sys_unbind(void)
{
  //
  // Optional: Your code here.
  //

  return 0;
}

//
// recv(int dport, int *src, short *sport, char *buf, int maxlen)
// if there's a received UDP packet already queued that was
// addressed to dport, then return it.
// otherwise wait for such a packet.
//
// sets *src to the IP source address.
// sets *sport to the UDP source port.
// copies up to maxlen bytes of UDP payload to buf.
// returns the number of bytes copied,
// and -1 if there was an error.
//
// dport, *src, and *sport are host byte order.
// bind(dport) must previously have been called.
//
uint64
sys_recv(void)
{
  /*
    recv(short dport, int *src, short *sport, char *buf, int maxlen): 
    This system call returns the payload of a UDP packet that arrives with destination port dport. If one or more packets arrived before the call to recv(), it should return right away with the earliest waiting packet. If no packets are waiting, recv() should wait until a packet for dport arrives. 
    
    recv() should see arriving packets for a given port in arrival order. recv() copies the packet's 32-bit source IP address to *src, copies the packet's 16-bit UDP source port number to *sport, copies at most maxlen bytes of the packet's UDP payload to buf, and removes the packet from the queue. The system call returns the number of bytes of the UDP payload copied, or -1 if there was an error. 
  */

  // PART I - Get CLI arguments
  // struct proc *p = myproc();
  int dport;
  int src;
  int sport;
  uint64 bufaddr;
  int maxlen;

  argint(0, &dport);
  argint(1, &src);
  argint(2, &sport);
  argaddr(3, &bufaddr);
  argint(4, &maxlen);

  int found = 0;
  int len = maxlen;

  // PART II - Check if the port has been binded
  int i = 0;
  for (; i < 16; i++)
  {
    if (dport == bq[i].port)
    {
      found = 1;
      // printf("sys_recv: port %d bound, proceeding to next step.\n", dport);
      break;
    }
  }

  if (!found)
  {
    // printf("sys_recv: port %d not bound yet, call bind(%d) first.\n", dport, dport);
    return -1;
  }

  // PART III - wait until a packet arrives
  acquire(&bq[i].queuelock);
  while (bq[i].count == 0)
  {
    // printf("sys_recv: stuck on %d\n", dport);
    // bq_dump();

    sleep(&bq, &bq[i].queuelock);
  }
  // printf("sys_recv: unstuck on %d\n", dport);
  // bq_dump();

  // PART IV - If some packet arrives, process
  // acquire(&bq[i].queuelock);
  // printf("sys_recv: ready to process the first packets\n");
  // printf("sys_recv: len is %d.\n", bq[i].q[0].len);
  len = bq[i].q[0].len;
  // NOTE: from what I see len < maxlen
  if (len > maxlen)
    len = maxlen;

  /*
    struct packet {
      char* buf;
      int len;  // length of buffer
    };

    struct bindqueue{
      struct spinlock queuelock;
      int port;
      int count;
      struct packet q[16];
    };
  */
  // Process the first item, free the underlying buffer, and move ever other blocks to the left. Remember to decrement count
  struct eth *eth = (struct eth *) bq[i].q[0].buf;
  struct ip *ip = (struct ip *)(eth + 1);
  struct udp *udp = (struct udp *)(ip + 1);
  void *payload = (void *)(udp + 1);  // Do we actually have this?

  // The destination addresses that sys_recv() copies the packets to are virtual addresses; you will have to copy from the kernel to the current user process. 
  
  // Cannot memmove as src, sport and bufaddr are in user land (at least said so in hint)
  struct proc *p = myproc();
  pagetable_t pt = p->pagetable;
  ip->ip_src = htonl(ip->ip_src);
  ip->ip_dst = htonl(ip->ip_dst);
  udp->dport = htons(udp->dport);
  udp->sport = htons(udp->sport);
  udp->ulen = htons(udp->ulen);
  
  // return payload size: payload = udp.ulen - udp header size (8 bytes)
  // save it here before kfree()
  int returnlen = udp->ulen - sizeof(struct udp);

  // printf("sys_recv: UDP len is %d\n", udp->ulen);
  // ip->ip_src = ip->ip_src;
  // udp->dport = udp->dport;
  if (copyout(pt, src, (char *)&(ip->ip_src), 4) != 0)
  {
    printf("sys_recv: copyout() ip_src failed\n");
    return -1;
  }
  if (copyout(pt, sport, (char *)udp, 2) != 0)
  {
    printf("sys_recv: copyout() udp failed\n");
    return -1;
  }
  if (copyout(pt, bufaddr, (char *)payload, returnlen) != 0)
  {
    printf("sys_recv: copyout() buffer failed\n");
    return -1;
  }

  // Now free queue buffer
  kfree(bq[i].q[0].buf);

  // Move every ensuite block to the left
  for (int j = 1; j < 16; j++)
  {
    if (bq[i].q[j].buf == 0)
      break;
    bq[i].q[j - 1].buf = bq[i].q[j].buf;
    bq[i].q[j - 1].len = bq[i].q[j].len;
  }

  // Decrease total packet count for this dport
  bq[i].count--;
  release(&bq[i].queuelock);

  return returnlen;
}

// Debug
// Dump bq
void
bq_dump(void)
{
  for (int i = 0; i < 16; i++)
  {
    if (bq[i].port == 0)
      break;
    printf("bq_dump: port %d ", bq[i].port);
    for (int j = 0; j < 16; j++)
    {
      // if (bq[i].q[j].len == 0)
      // {
      //   break;
      // }
      printf("q%d->%p ", j, (void *)(bq[i].q[j].buf));
    }
    printf("\n");
  }
}

// This code is lifted from FreeBSD's ping.c, and is copyright by the Regents
// of the University of California.
static unsigned short
in_cksum(const unsigned char *addr, int len)
{
  int nleft = len;
  const unsigned short *w = (const unsigned short *)addr;
  unsigned int sum = 0;
  unsigned short answer = 0;

  /*
   * Our algorithm is simple, using a 32 bit accumulator (sum), we add
   * sequential 16 bit words to it, and at the end, fold back all the
   * carry bits from the top 16 bits into the lower 16 bits.
   */
  while (nleft > 1)  {
    sum += *w++;
    nleft -= 2;
  }

  /* mop up an odd byte, if necessary */
  if (nleft == 1) {
    *(unsigned char *)(&answer) = *(const unsigned char *)w;
    sum += answer;
  }

  /* add back carry outs from top 16 bits to low 16 bits */
  sum = (sum & 0xffff) + (sum >> 16);
  sum += (sum >> 16);
  /* guaranteed now that the lower 16 bits of sum are correct */

  answer = ~sum; /* truncate to 16 bits */
  return answer;
}

//
// send(int sport, int dst, int dport, char *buf, int len)
//
uint64
sys_send(void)
{
  struct proc *p = myproc();
  int sport;
  int dst;
  int dport;
  uint64 bufaddr;
  int len;

  argint(0, &sport);
  argint(1, &dst);
  argint(2, &dport);
  argaddr(3, &bufaddr);
  argint(4, &len);

  // NOTE: Cannot send more than one page of data
  int total = len + sizeof(struct eth) + sizeof(struct ip) + sizeof(struct udp);
  if(total > PGSIZE)
    return -1;

  char *buf = kalloc();
  if(buf == 0){
    printf("sys_send: kalloc failed\n");
    return -1;
  }
  memset(buf, 0, PGSIZE);

  // Filling Ethernet packet header data
  struct eth *eth = (struct eth *) buf;
  memmove(eth->dhost, host_mac, ETHADDR_LEN);
  memmove(eth->shost, local_mac, ETHADDR_LEN);
  eth->type = htons(ETHTYPE_IP);

  // Filling IP packet header data
  struct ip *ip = (struct ip *)(eth + 1);
  ip->ip_vhl = 0x45; // version 4, header length 4*5
  ip->ip_tos = 0;
  ip->ip_len = htons(sizeof(struct ip) + sizeof(struct udp) + len);
  ip->ip_id = 0;
  ip->ip_off = 0;
  ip->ip_ttl = 100;
  ip->ip_p = IPPROTO_UDP;
  ip->ip_src = htonl(local_ip);
  ip->ip_dst = htonl(dst);
  ip->ip_sum = in_cksum((unsigned char *)ip, sizeof(*ip));

  // Filling UDP packet header data
  struct udp *udp = (struct udp *)(ip + 1);
  udp->sport = htons(sport);
  udp->dport = htons(dport);
  udp->ulen = htons(len + sizeof(struct udp));

  char *payload = (char *)(udp + 1);
  // int copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
  if(copyin(p->pagetable, payload, bufaddr, len) < 0){
    kfree(buf);
    printf("send: copyin failed\n");
    return -1;
  }

  e1000_transmit(buf, total);

  return 0;
}

void
ip_rx(char *buf, int len)
{
  // don't delete this printf; make grade depends on it.
  static int seen_ip = 0;
  if(seen_ip == 0)
    printf("ip_rx: received an IP packet\n");
  seen_ip = 1;

  /*
    NOTE: Judging from arp_rx(), roughly we should do the following:
    - Create an ethernet header
    - Create an ip header
    - Create an output buffer to contain the two headers
    - Fill in the ethernet header with the contents in input buffer
    - Fill in the ip header (not sure how to do it, gotta check)
    - call e1000_transmit()
    - free incoming buffer
  */

  // Check whether the packet is UDP
  // 14-byte ETH + 20-byte IP + 8-byte UDP
  // printf("ip_rx: len is %d\n", len);
  if (len < 42)
    return;

  // Check if port is binded
  // If UDP, from what I get, dport should be buf[36] << 8 + buf[37]
  // int dport = (buf[34] << 8) + buf[35];
  struct eth *eth = (struct eth *)buf;
  struct ip *ip = (struct ip *)(eth + 1);
  struct udp *udp = (struct udp *)(ip + 1);
  int dport = htons(udp->dport);
  // printf("ip_rx: looking for port %d\n", dport);

  int found = 0;
  int i = 0;
  for (; i < 16; i++)
  {
    if (dport == bq[i].port)
    {
      found = 1;
      // printf("ip_rx: data in dport %d\n", dport);
      break;
    }
  }

  if (!found)
  {
    // printf("ip_rx: port %d is NOT binded, call bind(%d)\n", dport, dport);
    return;
  }
  else
  {
    // printf("ip_rx: port %d is binded, proceeding to next step\n", dport);
  }

  // Save the packet to bq
  /*
    struct packet {
      char* buf;
      int len;  // length of buffer
    };

    struct bindqueue{
      struct spinlock queuelock;
      int port;
      int count;
      struct packet q[16];
    };

  */
  acquire(&bq[i].queuelock);
  int bqcount = bq[i].count;
  if (bqcount == 16)
  {
    // printf("ip_rx: queue for port %d is full\n", dport);
    // free buf
    kfree(buf);
  }
  else
  {
    // Dump into the next available block, and increment count
    bq[i].q[bqcount].buf = kalloc();
    memmove(bq[i].q[bqcount].buf, buf, len);
    bq[i].q[bqcount].len = len;
    bq[i].count++;
    wakeup(&bq);
  }
  release(&bq[i].queuelock);

  // printf("ip_rx: all done\n");

  return;
}

//
// send an ARP reply packet to tell qemu to map
// xv6's ip address to its ethernet address.
// this is the bare minimum needed to persuade
// qemu to send IP packets to xv6; the real ARP
// protocol is more complex.
//
void
arp_rx(char *inbuf)
{
  static int seen_arp = 0;

  if(seen_arp){
    kfree(inbuf);
    return;
  }
  printf("arp_rx: received an ARP packet\n");
  seen_arp = 1;

  struct eth *ineth = (struct eth *) inbuf;
  struct arp *inarp = (struct arp *) (ineth + 1);

  char *buf = kalloc();
  if(buf == 0)
    panic("send_arp_reply");
  
  struct eth *eth = (struct eth *) buf;
  memmove(eth->dhost, ineth->shost, ETHADDR_LEN); // ethernet destination = query source
  memmove(eth->shost, local_mac, ETHADDR_LEN); // ethernet source = xv6's ethernet address
  eth->type = htons(ETHTYPE_ARP);

  struct arp *arp = (struct arp *)(eth + 1);
  arp->hrd = htons(ARP_HRD_ETHER);
  arp->pro = htons(ETHTYPE_IP);
  arp->hln = ETHADDR_LEN;
  arp->pln = sizeof(uint32);
  arp->op = htons(ARP_OP_REPLY);

  memmove(arp->sha, local_mac, ETHADDR_LEN);
  arp->sip = htonl(local_ip);
  memmove(arp->tha, ineth->shost, ETHADDR_LEN);
  arp->tip = inarp->sip;

  e1000_transmit(buf, sizeof(*eth) + sizeof(*arp));

  // NOTE: arp_rx frees the buffer passed from net_rx(), which is passed from e1000_recv
  kfree(inbuf);
}

void
net_rx(char *buf, int len)
{
  struct eth *eth = (struct eth *) buf;

  if(len >= sizeof(struct eth) + sizeof(struct arp) &&
     ntohs(eth->type) == ETHTYPE_ARP){
    arp_rx(buf);
  } else if(len >= sizeof(struct eth) + sizeof(struct ip) &&
     ntohs(eth->type) == ETHTYPE_IP){
    ip_rx(buf, len);
  } else {
    kfree(buf);
  }
}

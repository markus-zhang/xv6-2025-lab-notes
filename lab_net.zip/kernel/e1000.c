#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "e1000_dev.h"

#define TX_RING_SIZE 16
static struct tx_desc tx_ring[TX_RING_SIZE] __attribute__((aligned(16)));

#define RX_RING_SIZE 16
/* 
  NOTE: an array of 16 "descriptors" that describe buffers into which E1000 can write received packets.
*/
static struct rx_desc rx_ring[RX_RING_SIZE] __attribute__((aligned(16)));

// remember where the e1000's registers live.
static volatile uint32 *regs;

struct spinlock e1000_lock;

// int rx_ring_top;  // Top indices of rx_ring that contains data
static int rx_ring_count(void);
static void rx_ring_dump(void);

// Debug
static void e1000_dump_tx(void);

// called by pci_init().
// xregs is the memory address at which the
// e1000's registers are mapped.
// this code loosely follows the initialization directions
// in Chapter 14 of Intel's Software Developer's Manual.
void
e1000_init(uint32 *xregs)
{
  int i;

  initlock(&e1000_lock, "e1000");

  regs = xregs;

  // Reset the device
  regs[E1000_IMS] = 0; // disable interrupts
  regs[E1000_CTL] |= E1000_CTL_RST;
  regs[E1000_IMS] = 0; // redisable interrupts
  __sync_synchronize();

  // [E1000 14.5] Transmit initialization
  memset(tx_ring, 0, sizeof(tx_ring));
  for (i = 0; i < TX_RING_SIZE; i++) {
    tx_ring[i].status = E1000_TXD_STAT_DD;
    tx_ring[i].addr = 0;
  }
  regs[E1000_TDBAL] = (uint64) tx_ring;
  if(sizeof(tx_ring) % 128 != 0)
    panic("e1000");
  regs[E1000_TDLEN] = sizeof(tx_ring);
  regs[E1000_TDH] = regs[E1000_TDT] = 0;
  
  // [E1000 14.4] Receive initialization
  memset(rx_ring, 0, sizeof(rx_ring));
  for (i = 0; i < RX_RING_SIZE; i++) {
    rx_ring[i].addr = (uint64) kalloc();
    if (!rx_ring[i].addr)
      panic("e1000");
  }
  regs[E1000_RDBAL] = (uint64) rx_ring;
  if(sizeof(rx_ring) % 128 != 0)
    panic("e1000");
  regs[E1000_RDH] = 0;
  regs[E1000_RDT] = RX_RING_SIZE - 1;
  regs[E1000_RDLEN] = sizeof(rx_ring);

  // filter by qemu's MAC address, 52:54:00:12:34:56
  regs[E1000_RA] = 0x12005452;
  regs[E1000_RA+1] = 0x5634 | (1<<31);
  // multicast table
  for (int i = 0; i < 4096/32; i++)
    regs[E1000_MTA + i] = 0;

  // transmitter control bits.
  regs[E1000_TCTL] = E1000_TCTL_EN |  // enable
    E1000_TCTL_PSP |                  // pad short packets
    (0x10 << E1000_TCTL_CT_SHIFT) |   // collision stuff
    (0x40 << E1000_TCTL_COLD_SHIFT);
  regs[E1000_TIPG] = 10 | (8<<10) | (6<<20); // inter-pkt gap

  // receiver control bits.
  regs[E1000_RCTL] = E1000_RCTL_EN | // enable receiver
    E1000_RCTL_BAM |                 // enable broadcast
    E1000_RCTL_SZ_2048 |             // 2048-byte rx buffers
    E1000_RCTL_SECRC;                // strip CRC
  
  // ask e1000 for receive interrupts.
  regs[E1000_RDTR] = 0; // interrupt after every received packet (no timer)
  regs[E1000_RADV] = 0; // interrupt after every packet (no timer)
  regs[E1000_IMS] = (1 << 7); // RXDW -- Receiver Descriptor Write Back
}

int
e1000_transmit(char *buf, int len)
{
  //
  // Your code here.
  //
  // buf contains an ethernet frame; program it into
  // the TX descriptor ring so that the e1000 sends it. Stash
  // a pointer so that it can be freed after send completes.
  //
  // return 0 on success.
  // return -1 on failure (e.g., there is no descriptor available)
  // so that the caller knows to free buf.
  //

  /*
    NOTE: hints from the lab
    - First ask the E1000 for the TX ring index at which it's expecting the next packet, by reading the E1000_TDT control register.

    - Then check if the the ring is overflowing. If E1000_TXD_STAT_DD is not set in the descriptor indexed by E1000_TDT, the E1000 hasn't finished the corresponding previous transmission request, so return an error.

    - Otherwise, use kfree() to free the last buffer that was transmitted from that descriptor (if there was one).

    - Then fill in the descriptor. Set the necessary cmd flags (look at Section 3.3 in the E1000 manual).

    - Finally, update the ring position by adding one to E1000_TDT modulo TX_RING_SIZE. 
  */

  acquire(&e1000_lock);

  // - First ask the E1000 for the TX ring index at which it's expecting the next packet, by reading the E1000_TDT control register.
  // Reg base address from pci_init()
  uint32* e1000_regs = (uint32*)0x40000000L;
  uint32 e1000_tdt = e1000_regs[E1000_TDT];
  // printf("e1000: tail index at %d\n", e1000_tdt);

  // - Then check if the the ring is overflowing. If E1000_TXD_STAT_DD is not set in the descriptor indexed by E1000_TDT, the E1000 hasn't finished the corresponding previous transmission request, so return an error.

  uint8 status = tx_ring[e1000_tdt].status;
  // printf("e1000: tail descriptor status: %d\n", status);

  if ((status & E1000_TXD_STAT_DD) == 0)
  {
    // printf("e1000_transmit: tail descriptor not transmitted yet\n");
    return -1;
  }
  else 
  {
    // printf("e1000_transmit: tail descriptor transmitted, proceeding...\n");
    // printf("e1000_transmit: preparing to free page at - 0x%lx\n", tx_ring[e1000_tdt].addr);
  }

  // - Otherwise, use kfree() to free the last buffer that was transmitted from that descriptor (if there was one). But beware of new buffers that only contains 0.
  // NOTE: So looks like e1000_transmit() is responsible to free buf sent from say arp_tx(), which make sense, because it is going to use that pointer to buffer,
  if (tx_ring[e1000_tdt].addr != 0)
    kfree((void*)(tx_ring[e1000_tdt].addr));
  // kfree((void*)(PGROUNDDOWN(tx_ring[e1000_tdt].addr)));

  // - Then fill in the descriptor. Set the necessary cmd flags (look at Section 3.3 in the E1000 manual).
  /*
    NOTE:
    1. addr should be the buffer address
    2. length is the length of buffer(len)
    3. WHY cso should be 0 ?? 
    4. cmd: 76543210
            00011001
        I'm not sure about most of the cmd bits
        - bit 7: IDE - Not sure, WTH?
        - bit 6: VLE - Not sure, WTF?
        - bit 5: DEXT - should be 0 for legacy mode
        - bit 4: RPS (Report Packet Sent) - judging from lab should be set
        - bit 3: RS (Report Status) - set status.DD bit whence a dscriptor is    done and packets have been buffered in the transmit FIFO
        - bit 0: EOP (End of Packet) - set indicates the last descriptor making up the packet (I think for my case it's one packet one descriptor?)
    5. status: DD (bit 0) is set when the descriptor is finished, after the packet has been transmitted on the wire
    6. css: where to begin computing the checksum (I think for my case it's 0)
    7. special: no idea ???
  */

  tx_ring[e1000_tdt].addr = (uint64)buf;
  tx_ring[e1000_tdt].length = len;
  tx_ring[e1000_tdt].cso = 0;
  tx_ring[e1000_tdt].cmd = 0x19;
  tx_ring[e1000_tdt].status = 0;
  tx_ring[e1000_tdt].css = 0;
  tx_ring[e1000_tdt].special = 0;

  // - Finally, update the ring position by adding one to E1000_TDT modulo TX_RING_SIZE. 
  // WHY????? Oh I see, because it is a ring buffer, so once we go over TX_RING_SIZE we are back to 0, 1, etc...

  e1000_regs[E1000_TDT] = (e1000_tdt + 1) % TX_RING_SIZE;

  release(&e1000_lock);

  // Debug
  // e1000_dump_tx();
  return 0;
}

// Debug helper: what's inside tx_ring?
static void 
e1000_dump_tx(void)
{
  int i = 0;
  for (; i < TX_RING_SIZE; i++)
  {
    if (tx_ring[i].addr == 0)
      break;
  }
  printf("TX_RING %d - addr 0x%lx length %d\n", i-1, tx_ring[i-1].addr, tx_ring[i-1].length);
}

static void
e1000_recv(void)
{
  /*
    NOTE: Hints from the lab

    First ask the E1000 for the ring index at which the next waiting received packet (if any) is located, by fetching the E1000_RDT control register and adding one modulo RX_RING_SIZE.

    Then check if a new packet is available by checking for the E1000_RXD_STAT_DD bit in the status portion of the descriptor. If not, stop.

    Deliver the packet buffer to the network stack by calling net_rx().

    Then allocate a new buffer using kalloc() to replace the one just given to net_rx(). Clear the descriptor's status bits to zero.

    Finally, update the E1000_RDT register to be the index of the last ring descriptor processed.

    e1000_init() initializes the RX ring with buffers, and you'll want to look at how it does that and perhaps borrow code.

    At some point the total number of packets that have ever arrived will exceed the ring size (16); make sure your code can handle that.

    The e1000 can deliver more than one packet per interrupt; your e1000_recv should handle that situation. 
  */

  // Acquire lock to prevent more data coming into the descriptor array
  // acquire(&e1000_lock);

  // - First ask the E1000 for the ring index at which the next waiting received packet (if any) is located, by fetching the E1000_RDT control register and adding one modulo RX_RING_SIZE.
  uint32* e1000_regs = (uint32*)0x40000000L;
  uint32 e1000_rdt = e1000_regs[E1000_RDT];
  uint32 e1000_rdh = e1000_regs[E1000_RDH];
  // printf("e1000_recv: head %d tail %d\n", e1000_rdh, e1000_rdt);

  // - Then check if a new packet is available by checking for the E1000_RXD_STAT_DD bit in the status portion of the descriptor. If not, stop.
  // uint32 e1000_rindex = (e1000_rdt + 1) % RX_RING_SIZE;
  // int status = rx_ring[e1000_rindex].status;

  int i = (e1000_rdt + 1) % RX_RING_SIZE;
  for (; i != e1000_rdh ; i = (i + 1) % RX_RING_SIZE)
  {
    // if (i == e1000_rdh)
    //   break;

    int status = rx_ring[i].status;
    // printf("status: %d\n", status);
    if ((status & 0x1) == 0)
    {
      // Manual: Any descriptor with a non-zero status byte has been processed by the hardware, and is ready to be handled by the software.
      // i++;
      continue;
      // return;
    }
    // - Deliver the packet buffer to the network stack by calling net_rx().
    else
    {
      net_rx((char*)(rx_ring[i].addr), rx_ring[i].length);
      // - Then allocate a new buffer using kalloc() to replace the one just given to net_rx(). Clear the descriptor's status bits to zero.
      rx_ring[i].addr = (uint64)kalloc(); // Now addr points to a new buffer
      // rx_ring[e1000_rindex].length = 0;
      // rx_ring[e1000_rindex].csum = 0;
      rx_ring[i].status = 0;
      // rx_ring[e1000_rindex].errors = 0;
      // rx_ring[e1000_rindex].special = 0;

      // - Finally, update the E1000_RDT register to be the index of the last ring descriptor processed.
      e1000_regs[E1000_RDT] = i;

      // EOP bit is 0 then not the last descriptor
      // if ((status & 0x02) == 0x02)
      // {
      //   // printf("e1000_recv: last discriptor reached.\n");
      //   break;
      // }
      // else
      //   e1000_rindex += 1;   
    }
  }

  // release(&e1000_lock);

}

void
e1000_intr(void)
{
  // tell the e1000 we've seen this interrupt;
  // without this the e1000 won't raise any
  // further interrupts.
  regs[E1000_ICR] = 0xffffffff;

  e1000_recv();
}

static int 
rx_ring_count(void)
{
  int i = 0;
  for (; i < RX_RING_SIZE; i++)
  {
    // NOTE: after allocation, length is still 0
    if (rx_ring[i].length == 0)
      break;
  }
  return i;
}

static void
rx_ring_dump(void)
{
  for (int i = 0; i < RX_RING_SIZE; i++)
  {
    // NOTE: after recv, csum is still 0, not sure why, so I use length
    if (rx_ring[i].length == 0)
      break;

    printf("Buffer %d: addr -> 0x%lx  length -> %d  csum -> %d  status -> %d\n", 
      i, rx_ring[i].addr, rx_ring[i].length, rx_ring[i].csum, rx_ring[i].status);
  }
}

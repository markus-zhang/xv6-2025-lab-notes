// Physical memory allocator, for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel.
                   // defined by kernel.ld.

struct run {
  struct run *next;
};

struct kernelmem {
  struct spinlock lock;
  struct run *freelist;
  // COW: every page of physical memory has a reference count (how many PTEs map to it)
  // NOTE: I cannot put the ref count into struct run because user will overwrite it
  // Page starts at pa KERNBASE + 0 has index 0, at pa KERNBASE + 4096 has index 1, etc.
  // Free memory starts from KERNBASE - Kernel test - Kernel data
  // refcount has index from 0 to 0x7FFF (total 32,768 or 0x8000 entries)
  // So refcount occupies 8 bytes * 32K = 256KB, which is OK
  // We can probably reduce the size by recognizing that NPROC is 64,
  // so we will have a maximum of 64 counts for one physical page, 
  // and a 2-byte short (max 0xFF) is good enough
  int refcount[(PHYSTOP - KERNBASE)/PGSIZE];
  int freecount;
};

struct kernelmem kmem;

void
kinit()
{
  initlock(&kmem.lock, "kmem");
  kmem.freecount = 0;
  freerange(end, (void*)PHYSTOP);
}

void
freerange(void *pa_start, void *pa_end)
{
  char *p;
  p = (char*)PGROUNDUP((uint64)pa_start);
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    kinitfree(p);
  printf("freerange: %d free pages\n", kmem.freecount);
}

// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kinitfree(void *pa)
{
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);

  r = (struct run*)pa;

  acquire(&kmem.lock);
  r->next = kmem.freelist;
  kmem.freelist = r;
  // FEAT -> COW: reset refcount to 0
  kmem.refcount[((uint64)pa - KERNBASE) / PGSIZE] = 0;
  release(&kmem.lock);
  kmem.freecount += 1;
}

// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    panic("kfree");

  /*
    FEAT: COW -> don't kfree until all references are gone
    We don't check PTE_COW here because it is really difficult to do reverse search
  */
  acquire(&kmem.lock);
  int refcount = kmem.refcount[((uint64)pa - KERNBASE) / PGSIZE];
  if (refcount <= 0)
    printf("kfree: refcount <= 0 for pa %p\n", pa);
  if (refcount > 1)
  {
    // printf("kfree: pa %p has more than 1 reference\n", pa);
    kmem.refcount[((uint64)pa - KERNBASE) / PGSIZE] -= 1;
    if ((uint64)pa == 0x0000000081756000)
      printf("Kfree idx=%ld pa=%p\n", ((uint64)pa - KERNBASE) / PGSIZE, pa);
    release(&kmem.lock);
    return;
  }
  release(&kmem.lock);

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);

  r = (struct run*)pa;

  acquire(&kmem.lock);
  r->next = kmem.freelist;
  kmem.freelist = r;
  // FEAT -> COW: reset refcount to 0
  kmem.refcount[((uint64)pa - KERNBASE) / PGSIZE] = 0;
  release(&kmem.lock);
  // printf("Kfree idx=%ld pa=%p\n", ((uint64)pa - KERNBASE) / PGSIZE, pa);
  // printf("%ld\n", ((uint64)pa - KERNBASE) / PGSIZE);
  // if (((uint64)pa - KERNBASE) / PGSIZE == 29987)
  if ((uint64)pa == 0x0000000081756000)
    printf("Kfree idx=%ld pa=%p refcount=%d\n", ((uint64)pa - KERNBASE) / PGSIZE, pa, kmem.refcount[((uint64)pa - KERNBASE) / PGSIZE]);
  kmem.freecount += 1;
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
  struct run *r;

  acquire(&kmem.lock);
  r = kmem.freelist;
  if(r)
    kmem.freelist = r->next;
  release(&kmem.lock);

  if(r)
    // Note that memset does not impact r, but impact the 4KB memory pointed by r
    memset((char*)r, 5, PGSIZE); // fill with junk

  // FEAT -> COW: Set refcount to 1 
  if(r)
    kmem.refcount[((uint64)r - KERNBASE) / PGSIZE] = 1;

  if(r)
  {
    kmem.freecount -= 1;
    if (kmem.freecount < 0)
      panic("kalloc: freecount < 0\n");
  }
  // printf("Kalloc idx=%ld pa=%p\n", ((uint64)r - KERNBASE) / PGSIZE, (void*)r);
  // printf("%ld\n", ((uint64)r - KERNBASE) / PGSIZE);
  // if (((uint64)r - KERNBASE) / PGSIZE == 29987)
  // if ((uint64)r == 0x0000000087f27000)
  //   printf("Kalloc idx=%ld pa=%p refcount=%d\n", ((uint64)r - KERNBASE) / PGSIZE, (void*)r, kmem.refcount[((uint64)r - KERNBASE) / PGSIZE]);
  return (void*)r;
}

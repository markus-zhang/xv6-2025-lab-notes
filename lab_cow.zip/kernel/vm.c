#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "elf.h"
#include "riscv.h"
#include "defs.h"
#include "spinlock.h"
#include "proc.h"
#include "fs.h"

/*
 * the kernel's page table.
 */
pagetable_t kernel_pagetable;

extern char etext[];  // kernel.ld sets this to end of kernel code.

extern char trampoline[]; // trampoline.S

// Make a direct-map page table for the kernel.
pagetable_t
kvmmake(void)
{
  pagetable_t kpgtbl;

  kpgtbl = (pagetable_t) kalloc();
  memset(kpgtbl, 0, PGSIZE);

  // uart registers
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);

  // virtio mmio disk interface
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);

  // PLIC
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);

  // map kernel text executable and read-only.
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);

  // map kernel data and the physical RAM we'll make use of.
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);

  // map the trampoline for trap entry/exit to
  // the highest virtual address in the kernel.
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);

  // allocate and map a kernel stack for each process.
  proc_mapstacks(kpgtbl);
  
  return kpgtbl;
}

// add a mapping to the kernel page table.
// only used when booting.
// does not flush TLB or enable paging.
void
kvmmap(pagetable_t kpgtbl, uint64 va, uint64 pa, uint64 sz, int perm)
{
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    panic("kvmmap");
}

// Initialize the kernel_pagetable, shared by all CPUs.
void
kvminit(void)
{
  kernel_pagetable = kvmmake();
}

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));

  // flush stale entries from the TLB.
  sfence_vma();
}

// Return the address of the PTE in page table pagetable
// that corresponds to virtual address va.  If alloc!=0,
// create any required page-table pages.
//
// The risc-v Sv39 scheme has three levels of page-table
// pages. A page-table page contains 512 64-bit PTEs.
// A 64-bit virtual address is split into five fields:
//   39..63 -- must be zero.
//   30..38 -- 9 bits of level-2 index.
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
  if(va >= MAXVA)
    panic("walk");

  for(int level = 2; level > 0; level--) {
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) {
      pagetable = (pagetable_t)PTE2PA(*pte);
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
}

// Look up a virtual address, return the physical address,
// or 0 if not mapped.
// Can only be used to look up user pages.
uint64
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    return 0;

  pte = walk(pagetable, va, 0);
  if(pte == 0)
    return 0;
  if((*pte & PTE_V) == 0)
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}

// Create PTEs for virtual addresses starting at va that refer to
// physical addresses starting at pa.
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    panic("mappages: size not aligned");

  if(size == 0)
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
      return -1;
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

/*
  FEAT -> COW specific mappages (experimental and should merge with mappages() at the end)
  - This only takes care of the child proc (parent proc taken care in uvmcopy2())
  - switch child proc's PTE to RO, after backing up PTE_W to PTE_WB
  - mark child proc's PTE as COW PTE
*/
int
forkpages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    panic("mappages: size not aligned");

  if(size == 0)
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;

  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
      return -1;
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;

    // Backup PTE_W as PTE_WB
    int pte_wbit = perm & PTE_W;
    if (pte_wbit > 0)
      *pte |= PTE_WB;

    // Clear PTE_W
    *pte &= (~PTE_W);

    // mark PTE_COW
    *pte |= PTE_COW;
    // printf("*pte: %lx\n", *pte);

    if(a == last)
      break;
    a += PGSIZE;
    pa += PGSIZE;
  }
  return 0;
}

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
  if(pagetable == 0)
    return 0;
  memset(pagetable, 0, PGSIZE);
  return pagetable;
}

// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
// FEAT: COW -> I don't think I need to change this function, everything seems to be fine with CoW turned on
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
      continue;   
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
  }
}

// Allocate PTEs and physical memory to grow a process from oldsz to
// newsz, which need not be page aligned.  Returns new size or 0 on error.
uint64
uvmalloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz, int xperm)
{
  char *mem;
  uint64 a;

  if(newsz < oldsz)
    return oldsz;

  oldsz = PGROUNDUP(oldsz);
  for(a = oldsz; a < newsz; a += PGSIZE){
    mem = kalloc();
    if(mem == 0){
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
    memset(mem, 0, PGSIZE);
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
      kfree(mem);
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
  }
  // printf("All done\n");
  return newsz;
}

// Deallocate user pages to bring the process size from oldsz to
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    return oldsz;

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}

// Recursively free page-table pages.
// All leaf mappings must already have been removed.

void
freewalk(pagetable_t pagetable)
{
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    pte_t pte = pagetable[i];
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    }
  }

  kfree((void*)pagetable);
}

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
  if(sz > 0)
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  // uptdump(pagetable, 2);
  freewalk(pagetable);
}

// Given a parent process's page table, copy
// its memory into a child's page table.
// Copies both the page table and the
// physical memory.
// returns 0 on success, -1 on failure.
// frees any allocated pages on failure.

// int
// uvmcopy(pagetable_t old, pagetable_t new, uint64 sz)
// {
//   pte_t *pte;
//   uint64 pa, i;
//   uint flags;
//   char *mem;

//   for(i = 0; i < sz; i += PGSIZE){
//     if((pte = walk(old, i, 0)) == 0)
//       continue;   // page table entry hasn't been allocated
//     if((*pte & PTE_V) == 0)
//       continue;   // physical page hasn't been allocated
//     // Get physical page address (aligned to 4KB)
//     pa = PTE2PA(*pte);
//     // Get the falgs (W\R\U\etc.) of parent proc pte
//     flags = PTE_FLAGS(*pte);

//     if((mem = kalloc()) == 0)
//       goto err;
//     memmove(mem, (char*)pa, PGSIZE);
    
//     if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
//       kfree(mem);
//       goto err;
//     }
//   }
//   return 0;

//  err:
//   uvmunmap(new, 0, i / PGSIZE, 1);
//   return -1;
// }

// Given a parent process's page table, copy
// its memory into a child's page table.
// Copies both the page table and the
// physical memory.
// returns 0 on success, -1 on failure.
// frees any allocated pages on failure.

/* 
  FEAT: COW, do not allocate new memory for child proc
  - Point both pagetables to the same physical page, no kalloc
    - This is for parent proc
    - Copy PTE_W (bit 2) to RSW bit 9. Need it to restore PTE_W in vmfault()
    - Set RSW bit 8. Designated as COW bit. I'll put it in header file.
    - Remember to increment refcount for the pa (how to access kmem?)

  - NOTE: uvmcopy() doesn't touch pages shared with kernel (trampoline/trapframe/etc.) so should be fine. There is no need to add logic to make sure that we don't need to set COW bit for kernel pages
*/

struct KmemState {
  struct spinlock lock;
  struct run *freelist;
  int refcount[(PHYSTOP - KERNBASE)/PGSIZE];
};

extern struct KmemState kmem;

int
uvmcopy(pagetable_t old, pagetable_t new, uint64 sz)
{
  pte_t *pte;
  uint64 pa, i;
  uint flags;

  for(i = 0; i < sz; i += PGSIZE){
    if((pte = walk(old, i, 0)) == 0)
      continue;   // page table entry hasn't been allocated
    if((*pte & PTE_V) == 0)
      continue;   // physical page hasn't been allocated
    // Get physical page address (aligned to 4KB)
    pa = PTE2PA(*pte);
    // Get the flags (W\R\U\etc.) of parent proc pte
    flags = PTE_FLAGS(*pte);

    /*
      FEAT: COW -> No need to kalloc(), commented out
      Also need to mappages() to pa instead of mem
      Also make parent PTE readonly (mappages() creates child PTE)
      Also need to increment refcount (maybe in mappages())

      I think it's safer to create a new mapping function
      specifically for uvmcopy()
      - No physical memory allocation except for the page table
      - 
    */
    
    // Step 0: Investigate whether the U bit is set, the guard page is in user space,
    // but its U bit is not set and we should not CoW it.
    // NOTE: Even when uvmcopy() never touches kernel pages, some user pages don't set U-bit, like guard pages
    if (isuser(pte) == 0)
    {
      // Old method
      char *mem;

      if((mem = kalloc()) == 0)
        goto err;
      memmove(mem, (char*)pa, PGSIZE);
    
      if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0)
      {
        kfree(mem);
        goto err;
      }
    }
    else 
    {

      // Step 1, forkpages() child proc's PTE to pa, READ-ONLY
      if (forkpages(new, i, PGSIZE, (uint64)pa, flags) != 0)
      {
        // Cannot kfree(pa) as the parent is using it
        goto err;
      }

      // Step 2, increment refcount, prevent race condition
      acquire(&kmem.lock);
      kmem.refcount[(pa - KERNBASE) / PGSIZE] += 1;
      release(&kmem.lock);

      // Debug
      // if (pa == 0x87f3d000 || pa == 0x87f3b000 || pa == 0x87f1b000)
        // printf("uvmcopy va: %lx, %lx, %d\n", i, pa, kmem.refcount[(pa - KERNBASE) / PGSIZE]);

      // Step 3, switch parent proc's PTE to RO, after backing up PTE_W to PTE_WB
      int pte_wbit = (*pte) & PTE_W;

      // If it's a RO page, don't need to COW it (shouldn't write into it anyway, so writing into it will cause a panic in vmcowfault()). We still share it though.
      if (pte_wbit > 0)
      {
        *pte |= PTE_WB;

        // Step 4, mark PTE RO
        *pte &= (~PTE_W);

        // Step 5, mark parent proc's PTE as COW PTE
        // If it's a RO page originally, I still mark it as a CoW page,
        // so that if some program tries to write into, the tirggered write fault sends a panic
        *pte |= PTE_COW;
      }
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 0);
  return -1;
}

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
  if(pte == 0)
    panic("uvmclear");
  *pte &= ~PTE_U;
}

// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error.
// int
// copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
// {
//   uint64 n, va0, pa0;
//   pte_t *pte;

//   while(len > 0){
//     va0 = PGROUNDDOWN(dstva);
//     if(va0 >= MAXVA)
//       return -1;
  
//     pa0 = walkaddr(pagetable, va0);
//     if(pa0 == 0) {
//       if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
//         return -1;
//       }
//     }

//     pte = walk(pagetable, va0, 0);
//     // forbid copyout over read-only user text pages.
//     if((*pte & PTE_W) == 0)
//       return -1;
      
//     n = PGSIZE - (dstva - va0);
//     if(n > len)
//       n = len;
//     memmove((void *)(pa0 + (dstva - va0)), src, n);

//     len -= n;
//     src += n;
//     dstva = va0 + PGSIZE;
//   }
//   return 0;
// }

// Copy from kernel to user.
// Copy len bytes from src to virtual address dstva in a given page table.
// Return 0 on success, -1 on error.
/*
  FEAT: COW -> copyout() should simulate COW behavior
*/
int
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  // Debug
  // uint64 vasrc = PGROUNDDOWN((uint64)src);
  // printf("copyout: src virtual addr is: %p\n", (void*)vasrc);
  // uint64 pasrc = walkaddr(pagetable, vasrc);
  // printf("copyout: src physical addr is: %p\n", (void*)pasrc);
  // pte_t *ptesrc = 0;
  // *ptesrc = PA2PTE(src);
  // printf("copyout: src pte value is: 0x%lx\n", *ptesrc);

  while(len > 0){
    // align va0 to bottom of page
    va0 = PGROUNDDOWN(dstva);
    if(va0 >= MAXVA)
      return -1;
    
    // get physical page bottom address
    pa0 = walkaddr(pagetable, va0);
    
    if(pa0 == 0) {
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
        return -1;
      }
    }

    pte = walk(pagetable, va0, 0);
    // forbid copyout over read-only user text pages.
    // TODO: Remove the following part because COW pages are always RO
    // if((*pte & PTE_W) == 0)
    //   return -1;

    /* 
      NOTE: COW -> Now that we get the pte, we should look at whether it is marked as CoW
      If it is a CoW page, we cannot simply write into it. We need to split it, as in vmcowfault()
      If it is not a CoW page, follow the original path
    */
    if (iscow(pte))
    {
      // If it was already split (refcount = 1), simply set the W bit (it can't be RO, otherwise we wouldn't split it in the first place) and clear the CoW bit.
      if (kmem.refcount[(pa0 - KERNBASE) / PGSIZE] == 1)
      {
        int perm = PTE_FLAGS(*pte);
        perm = (perm | PTE_W) & (~PTE_WB) & (~PTE_COW);
        *pte |= perm;
      }
      // Otherwise we need to split it manually
      else
      {
        // NOTE: forkpages() marks WB and then clears the W bit to force it to be RO
        // Here we split the page manually instead of relying on vmcowfault()
        if (*pte & (PTE_WB))
        {
          // Get a new physical page
          uint64 pa1 = (uint64)kalloc();
          if (pa1 == 0)
          {
            printf("copyout: kalloc() failed to allocate a physical page\n");
            return -1;
          }
          // Copy old page to new page
          pa1 = (uint64)memmove((void*)pa1, (void*)pa0, PGSIZE);
          if (pa1 == 0)
          {
            printf("copyout: memmove() failed to copy a physical page\n");
            return -1;
          }
          // Get flags, clear COW bit, set W bit, clear WB bit
          int perm = PTE_FLAGS(*pte);
          perm = (perm | PTE_W) & (~PTE_WB) & (~PTE_COW);
          // Switch pte to point to new page.
          *pte = PA2PTE(pa1);
          // Set flags
          *pte |= perm;
          // Decrement pa0 refcount, prevent race condition
          acquire(&kmem.lock);
          kmem.refcount[(pa0 - KERNBASE) / PGSIZE] -= 1;
          release(&kmem.lock);
          if (kmem.refcount[(pa0 - KERNBASE) / PGSIZE] < 0)
            panic("copyout: refcount < 0");

          // Switch pa0 to pa1, don't mess up the original page
          pa0 = pa1;
        }
        // If WB bit is not set, it means the original page is supposed to be RO,
        // 
        else
        {
          printf("copyout: original COW page is RO, kill\n");
          return -1;
        }
      }
    }
    // Not COW page, just check whether they are writable
    else
    {
      if((*pte & PTE_W) == 0)
        return -1;
    }
    n = PGSIZE - (dstva - va0);
    if(n > len)
      n = len;
    memmove((void *)(pa0 + (dstva - va0)), src, n);
  

    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}

// Copy from user to kernel.
// Copy len bytes to dst from virtual address srcva in a given page table.
// Return 0 on success, -1 on error.
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0) {
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
        return -1;
      }
    }
    n = PGSIZE - (srcva - va0);
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);

    len -= n;
    dst += n;
    srcva = va0 + PGSIZE;
  }
  return 0;
}

// Copy a null-terminated string from user to kernel.
// Copy bytes to dst from virtual address srcva in a given page table,
// until a '\0', or max.
// Return 0 on success, -1 on error.
int
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    va0 = PGROUNDDOWN(srcva);
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    if(n > max)
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
        got_null = 1;
        break;
      } else {
        *dst = *p;
      }
      --n;
      --max;
      p++;
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    return 0;
  } else {
    return -1;
  }
}

// allocate and map user memory if process is referencing a page
// that was lazily allocated in sys_sbrk().
// returns 0 if va is invalid or already mapped, or if
// out of physical memory, and physical address if successful.

uint64
vmfault(pagetable_t pagetable, uint64 va, int read)
{
  uint64 mem;
  struct proc *p = myproc();

  if (va >= p->sz)
    return 0;
  va = PGROUNDDOWN(va);
  if(ismapped(pagetable, va)) {
    return 0;
  }
  mem = (uint64) kalloc();
  if(mem == 0)
    return 0;
  memset((void *) mem, 0, PGSIZE);
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    kfree((void *)mem);
    return 0;
  }
  return mem;
}

/*
  FEAT: COW -> Comes from usertrap() 15 (copyout/copyin stays with vmfault() for now as I'm not sure whether CoW impacts them or not. This makes testing easier.), 13 is read so we don't care.

  But we still need to check for scause=15 for non-CoW pages.
  - Check if PTW_COW is set:
    - If PTW_COW == 0, just follow the original path
    - If PTW_COW == 1, check if PTW_WB is set:
      - If PTW_WB == 0 (originally a RO page), for 15 (write):
        - ERROR -> return 0, as the spec says "a process that tries to write such a page should be killed."
      - If PTW_WB == 1 (PTW_WB was set)
        - kalloc() a new page
        - memcopy() the original page to the new page
        - mappages() the PTEs to the new page and set PTW_W
        - Set PTW_W for the other set of PTEs (How do I find those?)
*/
uint64
vmcowfault(pagetable_t pagetable, uint64 va)
{
  // printf("vmcowfault: 15\n");
  uint64 mem = 0;
  struct proc *p = myproc();

  if (va >= p->sz)
    return 0;
  va = PGROUNDDOWN(va);

  if(ismapped(pagetable, va)) 
  {
    // Should be CoW pages, right? If it's non-CoW, it should panic because you are writing into a page that is supposed to be RO
    pte_t *pte = walk(pagetable, va, 0);
    // Save this pte so that we can clear the CoW bit later
    // volatile pte_t *pteold = pte;
    if (iscow(pte) == 0)
    {
      // Writing into a non-CoW page is illegal
      printf("vmcowfault: Writing (scause=15) into a non-CoW RO page %ldx pointed by PTE %ln is illegal.\n", va, pte);
      // panic("");
      kkill(p->pid);
    }
    else
    {
      // If refcount is already 1 (which means this pa already went through vmcowfault),
      // Then just mark it writable to make sure, and no need to split. Remove COW bit too.
      uint64 oldmem = PTE2PA(*pte);
      if (kmem.refcount[(oldmem - KERNBASE) / PGSIZE] == 1)
      {
          *pte |= PTE_W;
          *pte &= (~PTE_COW);
          *pte &= (~PTE_WB);
          return oldmem;
      }


      // Writing into a CoW page is a bit more complicated:
      // Case 1 - PTE_WB is 0, which means they are supposed to be RO, panic
      // Case 2 - PTE_WB is 1, we do the following:
      //    - kalloc() a new page
      //    - memcopy() the original page to the new page
      //    - mappages() the PTEs to the new page and set PTW_W
      //    - Set PTE_W for the other set of PTEs? (Actually, we don't need to do that as the other proc is not writing into the page, so why bother with it, right?)

      if (*pte & (PTE_WB))
      {
        // kalloc() a new page
        mem = (uint64)kalloc();
        if (mem == 0)
          panic("vmcowfault: kalloc() failed to allocate a physical page");
        // Copy memory from original page to the new page
        uint64 old = PTE2PA(*pte);
        mem = (uint64)memmove((void*)mem, (void*)old, PGSIZE);
        if (mem == 0)
          panic("vmcowfault: memmove() failed to copy a physical page");
        // mappages() the PTEs to the new page and set PTW_W
        // Note that right now pte was already mapped to the old physical page
        // NOTE: pte is level 0 pte, so we only need to change its content
        // Switch to new value (note that this changes both *pte and *pteold so we )
        *pte = PA2PTE(mem);
        // Set PTE_W
        *pte |= (PTE_W |PTE_U | PTE_R | PTE_V);
        // Clear PTE_COW for the new pte
        *pte &= ~(PTE_COW);
        // Decrement old pa refcount, prevent race condition
        acquire(&kmem.lock);
        kmem.refcount[(old - KERNBASE) / PGSIZE] -= 1;
        release(&kmem.lock);
        // printf("vmcowfault va: %lx, %lx, %d\n", va, old, kmem.refcount[(old - KERNBASE) / PGSIZE]);

        if (kmem.refcount[(old - KERNBASE) / PGSIZE] < 0)
        {
          panic("vmcowfault: refcount <= 0 after pa split");
        }
      }
      else
      {
        // Writing into a CoW page which was RO originally is illegal, should kill it
        printf("vmcowfault: Writing (scause=15) into a CoW page 0x%lx which was RO pointed by PTE 0x%lx is illegal.\n", va, (uint64)pte);
        // printf("*pte is 0x%lx\n", *pte);
        // panic("");
        kkill(p->pid);
      }

    }
  }
  else
  {
    // Non-CoW pages, just follow the old logic in vmfault()
    mem = (uint64) kalloc();
    if(mem == 0)
      return 0;
    memset((void *) mem, 0, PGSIZE);
    if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
      kfree((void *)mem);
      return 0;
    }
  }
  return mem;
}


int
ismapped(pagetable_t pagetable, uint64 va)
{
  pte_t *pte = walk(pagetable, va, 0);
  if (pte == 0) {
    return 0;
  }
  if (*pte & PTE_V){
    return 1;
  }
  return 0;
}

int
iscow(pte_t *pte)
{
  if (pte == 0)
  {
    return 0;
  }
  else
  {
    return (*pte & (PTE_COW));
  }
}

int
isuser(pte_t *pte)
{
  if (pte == 0)
  {
    return 0;
  }
  else
  {
    return (*pte & (PTE_U));
  }
}

/*
  NOTE: uvmdump() assumes that VA is contigous, except for the Trampoline and Trapframe pages.
  For each page, it prints the following:
  va, pte (level 0), *pte (level 0), pa, permission bits (including bit 8 and 9) and refcount
*/

void uvmdump(void)
{
  struct proc *p = myproc();
  if (p == 0)
  {
    printf("uvmdump: unable to locate current process\n");
    kexit(-1);
  }

  printf("uvmdump: dumping process %s pid %d\n", p->name, p->pid);

  uint64 sz = p->sz;
  pagetable_t pagetable = p->pagetable;
  uint64 pa;
  int perm;
  int refcount;

  // Let's dump trampoline first
  uint64 va = TRAMPOLINE;
  pte_t *pte = walk(pagetable, va, 0);
  if (pte == 0)
  {
    // No need to exit for this error, let's continue and see what else is broken
    printf("uvmdump: trampoline is not mapped\n");
  }
  else
  {
    pa = PTE2PA(*pte);
    perm = (*pte) & 0x3FF;  // bit 9 to bit 0
    acquire(&kmem.lock);
    refcount = kmem.refcount[(pa - KERNBASE) / PGSIZE];
    release(&kmem.lock);
    // printf("perm: %d\n", perm);
    printf("trampoline -> va: %p  pte: %p *pte: %p  pa: %p  perm: %xd refcount: %d\n", 
      (void*)va, (void*)pte, (void*)(*pte), (void*)pa, perm, refcount);
  }

  // Let's dump trapframe then
  va = TRAPFRAME;
  pte = walk(pagetable, va, 0);
  if (pte == 0)
  {
    // No need to exit for this error, let's continue and see what else is broken
    printf("uvmdump: trapframe is not mapped\n");
  }
  else
  {
    pa = PTE2PA(*pte);
    perm = (*pte) & 0x3FF;  // bit 9 to bit 0
    acquire(&kmem.lock);
    refcount = kmem.refcount[(pa - KERNBASE) / PGSIZE];
    release(&kmem.lock);
    printf("trapframe -> va: %p  pte: %p *pte: %p  pa: %p  perm: %xd refcount: %d\n", 
      (void*)va, (void*)pte, (void*)(*pte), (void*)pa, perm, refcount);
  }

  // regular user memory starting from 0 to sz
  for (va = 0; va < sz; va += PGSIZE)
  {
    pte = walk(pagetable, va, 0);
    if (pte == 0)
    {
      // No need to exit for this error, let's continue and see what else is broken
      printf("uvmdump: va %p is not mapped\n", (void*)va);
    }
    else
    {
      pa = PTE2PA(*pte);
      perm = (*pte) & 0x3FF;  // bit 9 to bit 0
      acquire(&kmem.lock);
      refcount = kmem.refcount[(pa - KERNBASE) / PGSIZE];
      release(&kmem.lock);
      // Let's focus on refcount > 1
      if (refcount >= 1)
        printf("va: %p  pte: %p *pte: %p  pa: %p  perm: %xd refcount: %d\n", 
            (void*)va, (void*)pte, (void*)(*pte), (void*)pa, perm, refcount);
    }
  }
}

/*
  0x0000000087f24000
  0x0000000087f21000
  0x0000000087f20000
  0x0000000087f1f000
  0x0000000087f1e000
  0x0000000087f1d000
  0x0000000087f1c000
  0x0000000087f1b000
*/


/*
  Another debug function that printf all valid PTE of a page table recursively
*/

void
uptdump(pagetable_t pagetable, int level)
{
  if (level < 0)
  {
    return;
  }
  if (level > 2)
  {
    printf("uptdump: level > 2 error\n");
    return;
  }

  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    pte_t* pte = &pagetable[i];

    if ((*pte) & PTE_V)
    {
      // A valid PTE, printf
      for (int i = 2 - level; i > 0; i--)
      {
        printf("\t");
      }
      printf("L%d pte @ %p with value %p\n", level, (void*)pte, (void*)(*pte));
      if (((*pte) & (PTE_R|PTE_W|PTE_X)) == 0)
      {
        // This PTE points to a lower level page table
        uint64 child = PTE2PA(*pte);
        uptdump((pagetable_t)child, level - 1);
      }
    }


    // if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    //   // this PTE points to a lower-level page table.
    //   uint64 child = PTE2PA(pte);
    //   freewalk((pagetable_t)child);
    //   pagetable[i] = 0;
    // } else if(pte & PTE_V){
    //   panic("freewalk: leaf");
    // }
  }
}
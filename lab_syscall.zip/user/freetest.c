#include "user/user.h"
#include "kernel/types.h"
#include "kernel/syscall.h"

int
main(void)
{
    printf("Free memory: %d\n", freemem());
    return 0;
}
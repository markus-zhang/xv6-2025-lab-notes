#include "kernel/types.h"
#include "kernel/fcntl.h"
#include "user/user.h"
#include "kernel/riscv.h"

#define DATASIZE (8*4096)

char steal[DATASIZE];

static int issecretchar(char c)
{
  if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
  {
    return 1;
  }
  return 0;
}


int
main(int argc, char *argv[])
{
  // Your code here.
  for (int i = 0; i < DATASIZE; i++)
  {
    if (steal[i] == 'T' && steal[i+1] == 'h')
    {
      // printf("We got it!\n");
      while(steal[i++] != '.')  {}
      // Somehow the string shows twice in memory, so we need to search again, I'm lazy so only search .
      // which is the last char. seems to be ok?
      if (steal[i] == '\0')
      {
        while(steal[i++] != '.')  {}
      }
      // There is a '\0' after .
      while (issecretchar(steal[i]) != 1) 
      {
        i++;
      }

      while (issecretchar(steal[i]) == 1)
      {
        printf("%c", steal[i]);
        i++;
      }
      printf("\n");
      return 0;
    }
  }
  // printf("We didn't get it!\n");

  exit(1);
}

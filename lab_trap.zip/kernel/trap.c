#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "proc.h"
#include "defs.h"

struct spinlock tickslock;
uint ticks;

extern char trampoline[], uservec[];

// in kernelvec.S, calls kerneltrap().
void kernelvec();

extern int devintr();

void
trapinit(void)
{
  initlock(&tickslock, "time");
}

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
  w_stvec((uint64)kernelvec);
}

//
// handle an interrupt, exception, or system call from user space.
// called from, and returns to, trampoline.S
// return value is user satp for trampoline.S to switch to.
//

/*
  NOTE: More information about how RISC-V hardware handles a trap (from xv6 book)

  When it forces a trap, the RISC-V hardware does the following:
  1. If the trap is a device interrupt, and the sstatus SIE bit is clear, don’t do any of the
  following. (I couldn't find the source)
  2. Disable interrupts by clearing the SIE bit in sstatus. (privileged manual, sstatus register)
  3. Copy the pc to sepc. (privileged manual, sepc register)
  4. Save the current mode (user or supervisor) in the SPP bit in sstatus.(privileged manual, sstatus register)
  5. Set scause to a number indicating the trap’s cause. (privileged manual, scause register)
  6. Set the mode to supervisor. (should be common sense but I couldn't find the source)
  7. Copy stvec to the pc. (privileged manual, stvec register)
  8. Start executing at the new pc.
*/
uint64
usertrap(void)
{
  int which_dev = 0;

  /*
    SPP in sstatus stores the privilege level BEFORE entering supervisor mode.
    Since this is usertrap(), we are supposed to deal with trap coming from user land,
    so we want to make sure about that
  */
  if((r_sstatus() & SSTATUS_SPP) != 0)
    panic("usertrap: not from user mode");

  // send interrupts and exceptions to kerneltrap(),
  // since we're now in the kernel.
  // If a trap occurs, we wany kernelvec to handle instead of uservec
  /*
    csrw stvec, %0
    atomic write (uint64)kernelvec into stvec, Supervisor Trap Vector Base Address Register
    When MODE=Direct, all traps into supervisor mode cause the pc to be set to the address in the BASE field. 
  */
  w_stvec((uint64)kernelvec);  //DOC: kernelvec

  struct proc *p = myproc();
  
  // save user program counter.
  /*
    From the manual:
    "When a trap is taken into S-mode, sepc is written with the virtual address of the instruction that was interrupted or that encountered the exception."

    https://riscv.github.io/riscv-isa-manual/snapshot/privileged/#_supervisor_exception_program_counter_sepc_register

    Here we save it into p->trapframe->epc
  */
  p->trapframe->epc = r_sepc();
  // Alarmtest debug
  // printf("usertrap: epc->0x%lx\n", p->trapframe->epc);
  
  /*
    https://riscv.github.io/riscv-isa-manual/snapshot/privileged/#scause
    In risc-v, system call is called "environment call", thus the instruction is ecall
  */
  if(r_scause() == 8){
    // system call

    if(killed(p))
      kexit(-1);

    // sepc points to the ecall instruction,
    // but we want to return to the next instruction.
    /*
      WHY: Looks like each instruction is 32-bit. But I know RISC-V does have 64-bit instructions.
    */
    p->trapframe->epc += 4;

    // an interrupt will change sepc, scause, and sstatus,
    // so enable only now that we're done with those registers.
    /*
      WHY: I don't know when interrupt is off (maybe the CPU automatically turns it off when a trap occurs, but I couldn't find it in the manual)
    */
    intr_on();

    syscall();
  }
  else if((which_dev = devintr()) != 0)
  {
    if (which_dev == 2) 
    {
      // Alarmtest: if alarmon is 1, increment alarmticks
      if (p->alarmon == 1)
      {
        p->alarmticks += 1;
        if (p->alarmticks >= p->alarmtriggerticks)
        {
          if (p->inalarm == 0)
          {
            // alarmtest: saving all these registers before modifying the epc
            p->ra = p->trapframe->ra;
            p->sp = p->trapframe->sp;
            p->s0 = p->trapframe->s0;
            p->s11 = p->trapframe->s11;
            p->a5 = p->trapframe->a5;
            p->a4 = p->trapframe->a4;
            p->a0 = p->trapframe->a0;
            p->epc = p->trapframe->epc;

      
            p->trapframe->epc = p->alarmfp;
            p->inalarm = 1;

            p->alarmticks = 0;
            p->alarmactivated = 1;
          }
        }
      }
    }
  }
  else if((r_scause() == 15 || r_scause() == 13) &&
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0)
  {
    // page fault on lazily-allocated page
  } else {
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    panic("");
    setkilled(p);
  }

  if(killed(p))
    kexit(-1);

  // give up the CPU if this is a timer interrupt.
  /*
    From the manual:
    "The mtime register has a 64-bit precision on all RV32 and RV64 systems. 
    Platforms provide a 64-bit memory-mapped machine-mode timer compare register (mtimecmp). 
    A machine timer interrupt becomes pending whenever mtime contains a value greater than or equal to mtimecmp, 
    treating the values as unsigned integers."
  */
  if(which_dev == 2)
    yield();

  prepare_return();

  // the user page table to switch to, for trampoline.S
  uint64 satp = MAKE_SATP(p->pagetable);

  // return to trampoline.S; satp value in a0.
  return satp;
}

//
// set up trapframe and control registers for a return to user space
// NOTE: that we are still in supervisor mode
void
prepare_return(void)
{
  struct proc *p = myproc();

  // we're about to switch the destination of traps from
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  /*
    NOTE: TRAMPOLINE is the base address of the trampoline page.
    The trampoline page contains uservec (see trampoline.S)
    trampoline is the address of the symbol/label "trampoline" in trampoline.S
    uservec is the address of the symbol/label "uservec" in trampoline.S
    In kvmmake(), which is called earlier by kvminit() in main.c, maps trampoline to TRAMPOLINE

    WHY: both in trap.c and vm.c, we can use extern char trampoline[] to point to the compiled code of the trampoline label in trampoline.S, why? Furthermore, using gdb p/x trampoline and p/x uservet, we can see that both addresses are at 0x80006000, which should be the offsets in the kernel image binary
    I think this is a typical way to add an "offset" to a base address, but I don't know why and how it works
  */
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
  /*
    stvec holds trap vector configuration.
  */
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
  p->trapframe->kernel_trap = (uint64)usertrap;
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()

  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
  x |= SSTATUS_SPIE; // enable interrupts in user mode
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
}

// interrupts and exceptions from kernel code go here via kernelvec,
// on whatever the current kernel stack is.

/*
  NOTE: Looks like kerneltrap() does not have the syscall part. 
  This is to be expected as syscall is from user land to kernel land.
*/
void 
kerneltrap()
{
  int which_dev = 0;
  uint64 sepc = r_sepc();
  uint64 sstatus = r_sstatus();
  uint64 scause = r_scause();
  
  /*
    Recall that RISC-V does not reveal what the CURRENT mode is, but what the previous mode was
  */
  if((sstatus & SSTATUS_SPP) == 0)
    panic("kerneltrap: not from supervisor mode");
  if(intr_get() != 0)
    panic("kerneltrap: interrupts enabled");

  if((which_dev = devintr()) == 0){
    // interrupt or trap from an unknown source
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    panic("kerneltrap");
  }

  // give up the CPU if this is a timer interrupt.
  if(which_dev == 2 && myproc() != 0)
    yield();

  // the yield() may have caused some traps to occur,
  // so restore trap registers for use by kernelvec.S's sepc instruction.
  w_sepc(sepc);
  w_sstatus(sstatus);
}

void
clockintr()
{
  if(cpuid() == 0){
    acquire(&tickslock);
    ticks++;
    wakeup(&ticks);
    release(&tickslock);
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
}

// check if it's an external interrupt or software interrupt,
// and handle it.
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    // this is a supervisor external interrupt, via PLIC.

    // irq indicates which device interrupted.
    int irq = plic_claim();

    if(irq == UART0_IRQ){
      uartintr();
    } else if(irq == VIRTIO0_IRQ){
      virtio_disk_intr();
    } else if(irq){
      printf("unexpected interrupt irq=%d\n", irq);
    }

    // the PLIC allows each device to raise at most one
    // interrupt at a time; tell the PLIC the device is
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
  }
}


#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  kexit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return kfork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return kwait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
  argint(1, &t);
  addr = myproc()->sz;

  if(t == SBRK_EAGER || n < 0) {
    if(growproc(n) < 0) {
      return -1;
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
      return -1;
    myproc()->sz += n;
  }
  return addr;
}

uint64
sys_pause(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  if(n < 0)
    n = 0;
  acquire(&tickslock);
  ticks0 = ticks;
  // backtrace lab
  backtrace();
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kkill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

uint64
sys_sigalarm(void)
{
  int n;
  uint64 fn;

  argint(0, &n);
  argaddr(1, &fn);

  struct proc *p = myproc();
  // printf("sys_sigalarm: proc name: %s, n: %d\n", p->name, n);
  
  /* if both n and fn are 0, stop the alarm*/
  if (n == 0 && fn == 0)
  {
    p->alarmon = 0;
    p->alarmticks = 0;
  }
  else
  {
    /*
      Turn on alarmon anyway because it's not STOP command (both 0)
      Check if alarmticks goes above n,
      if yes, call fp
      otherwise do nothing
    */
    p->alarmon = 1;
    p->alarmtriggerticks = n;
    p->alarmfp = fn;
  }
  return 0;
}

uint64
sys_sigreturn(void)
{
  /*
    OK maybe we should just modify the frame pointer?
    Return address is at fp-8
  */
  
  struct proc *p = myproc();
  // // printf("ra is: 0x%lx\n", p->trapframe->ra);
  // should write into sp-56
  // printf("ra loaded: 0x%lx\n", p->ra);

  // p->trapframe->ra = p->alarmreturnaddress;
  // p->trapframe->ra = 0x406;
  p->trapframe->ra = p->ra;
  p->trapframe->sp = p->sp;
  p->trapframe->s0 = p->s0;
  p->trapframe->s11 = p->s11;
  p->trapframe->a5 = p->a5;
  p->trapframe->a4 = p->a4;
  p->trapframe->a0 = p->a0;
  p->trapframe->epc = p->epc;
  // printf("epc is: 0x%lx\n", p->trapframe->epc);

  p->inalarm = 0;

  return 0;
}
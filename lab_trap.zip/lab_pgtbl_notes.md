### Superpage

#### One page table policy

- I have already added `ksuperalloc` and `ksuperfree`. I also added a `freesuperrange` function that `kinit` uses to allocate at least 15 superpages in the beginning. `freesuperrange` calls `ksuperfree` to build the super free list.

- TODO: Check `sys_sbrk` and `growproc` to call the super functions / use the super free list when the user wants to allocate > 2MB of memory

OK I have identified a problem with the one page table approach:

If I keep one page table for both 4KB and 2MB pages, I'll need to tell the functions which type of page they are going to alloc/dealloc/etc. This is mostly fine because I already know the type of pages when I call the functions.

However, `uvmcopy()` is an exception. It just goes through all PTEs and `kalloc()->memmove()` everything with the assumption that all pages are 4KB regular ones. It has no idea which ones are super pages and which are regular pages. AFAIK, I can't find an easy solution out of this issue. I *could* create a `struct pte` wrapper for each `pte_t` and put a label to indicate the type, but this requires me to update ALL code related to the PTE  (basically everything in vm.c and proc.c and exec.c and more). I'm hesitant to do so.


#### Two page table policy

OK so in this policy we keep two page tables, one for regular 4KB pages and the other for 2MB super pages. Let's identify the function call:

sys_sbrk(): Let's keep this function agnostic of the type of pages for now
-> growproc(): What if we keep this function agnostic of the type of pages too?

---> uvmalloc(): 

- Modifications to be made: it creates as many super pages as possible, and create regular pages for the rest. For example, let's say `newsz` - `oldsz` = 4MB + 16KB, then it should create 2 super pages and 4 regular pages.

- `uvmalloc()` should also tell `mappages()` which type of pages it needs to map. Since the virtual addresses of the super pages and the regular pages are not the same (it is the `a` variable in the for loop in `uvmalloc()`), we don't worry about same virtual addresses in different page tables. I could also create a seaprate `mapsuperpages()` for super pages.

- `uvmalloc()` should call `ksuperfree()` for super pages

- `uvdemalloc()` is a lot trickier so I'll discuss it in the next section

---> uvdemalloc():

- Well here is another problem: `uvdemalloc()` calls this:

```C
uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
```
This intends to remove npages of mappings starting from va PGROUNDUP(newsz). However, none of the functions knows whether we are unmapping super pages or regular pages.

We can use the fact that super pages has level 1 PTE's V and R bits set. Regular pages' level 1 PTE only has the V bit set. 

This requires a couple of changes in `walk()`: 

First, `walk()` when `alloc = 1` needs to know whether it is looking for/creating a super page PTE, if so then it should set the level 1 PTE's V and R bits. Something like this:

```C
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
        return 0;
      if (superpage  == 1)
      {
        memset(superpagetable, 0, SUPERPGSIZE);
        if (level == 1)
        {
            *pte = PA2PTE(superpagetable) | PTE_V | PTE_R;
        }
        else
        {
            *pte = PA2PTE(superpagetable) | PTE_V;
        }
      }
      else
      {
        memset(pagetable, 0, PGSIZE);
        *pte = PA2PTE(pagetable) | PTE_V;
      }
    }
```

Second, `walk()` should check level 1 pte to look for super pages, but how do we tell the caller function which type of page it is? I think we can pass another parameter to `walk()`:

```C
/*
    The idea is:
    If walk can find a pte, this means that the caller function is looking for a page,
    so we set `superpage` to notify it. We also use the level 1 PTE's V/R bits to check for super pages.
    If walk cannot find a pte, this means that the caller function is creating a page,
    so we don't care about `superpage` but set the level 1 V/R bits.
*/
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc, int* superpage)
{
  if(va >= MAXVA)
    panic("walk");

  for(int level = 2; level > 0; level--) {
    pte_t *pte = &pagetable[PX(level, va)];
    if(*pte & PTE_V) 
    {
      // when level = 2, we get level 1 pte
      if (level == 2)
      {
        if (*pte & PTE_R)
        {
            // We have got a super page PTE
            *superpage = 1;
        }
        else
        {
            *superpage = 0;
        }
      }
      pagetable = (pagetable_t)PTE2PA(*pte);
#ifdef LAB_PGTBL
      if(PTE_LEAF(*pte)) {
        return pte;
      }
#endif
    } 
    else 
    {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
        return 0;
      if (*superpage  == 1)
      {
        // page table for super pages should still only need 4KB (512 entries)
        memset(superpagetable, 0, PGSIZE);
        // When level = 2, we get level 1 pte
        if (level == 2)
        {
            *pte = PA2PTE(superpagetable) | PTE_V | PTE_R;
        }
        else
        {
            *pte = PA2PTE(superpagetable) | PTE_V;
        }
      }
      else
      {
        memset(pagetable, 0, PGSIZE);
        *pte = PA2PTE(pagetable) | PTE_V;
      }
    }
  }
  return &pagetable[PX(0, va)];
}
```

I also realized that we can still use the one-pagetable policy, because `uvmcopy()` uses `walk()`, so we can use ^ to tell whether it is a super page.

For `uvmalloc()`, we can make it smarter -> if the requested size is >= super page, then we can create super pages with a bunch of smaller regular pages. The caller doesn't care whether there are super pages created or not.

```C
uint64
uvmalloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz, int xperm)
{
  char *mem;
  uint64 a;
  int sz;

  if(newsz < oldsz)
    return oldsz;

  oldsz = PGROUNDUP(oldsz);
  a = oldsz;
  // Prioritize super page over regular pages
  for (; a < newsz && newsz-oldsz>=SUPERPAGESIZE;  a+= sz)
  {
    sz = SUPERPGSIZE;
    mem = ksuperalloc();
    if(mem == 0)
    {
      uvmdealloc(pagetable, a, oldsz);
    }
    memset(mem, 0, sz);
    // Should we tell mappages?
    // Note that mappages uses walk, so we just need to modify mappages to pass and check `superpage`
    // Actually, it might be easier to just tell mappages(), hmmmm...TODO: Check this
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
      kfree(mem);
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
  }
  // regular page allocator should continue
  for(; a < newsz; a += sz){
    sz = PGSIZE;
    mem = kalloc();
    if(mem == 0){
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
#ifndef LAB_SYSCALL
    memset(mem, 0, sz);
 #endif
    if(mappages(pagetable, a, sz, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
      kfree(mem);
      uvmdealloc(pagetable, a, oldsz);
      return 0;
    }
  }
  return newsz;
}
```

Now we need to modify `mappages()` to accept an extra argument: (or create a superpage version of `mappages()`)
TODO: Complete the following program, too tired to continue

```C
int
mapsuperpages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
  uint64 a, last;
  pte_t *pte;

  if((va % SUPERPGSIZE) != 0)
    panic("mapsuperpages: va not aligned");

  if((size % SUPERPGSIZE) != 0)
    panic("mapsuperpages: size not aligned");

  if(size == 0)
    panic("mapsuperpages: size");
  
  a = va;
  last = va + size - SUPERPGSIZE;
  for(;;){
    int superpage = 1;
    if((pte = walk(pagetable, a, 1, superpage)) == 0)
      return -1;
    if (superpage == 0)
      // Not supposed to change superpage
      // So if superpage is changed to 0, it means walk() actually found a regular page already mapped (in walk() the else branch does not modify superpage)
      printf("mapsuperpages: supposed to create mapping for super pages, but got regular mapped pte: %p\n", pte);
      panic("mappages: remap);
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += SUPERPGSIZE;
    pa += SUPERPGSIZE;
  }
  return 0;
}
```

Then we must modify `uvmdealloc()`: Unfortunately it defaults to regular pages, so we need to check the functions who call `uvmdealloc()` and see if we can pass thie piece of information:

- `uvmallov()` calls `uvmdealloc()` if `mappages()` fails, this is good because `uvmalloc()` know which type of pages we are allocating;

- `growproc()` calls `uvmdealloc()` if n < 0 (shrink size), this is NOT good because `growproc()` has no information of the memory layout.

Maybe we can do this:

- Assuming memory allocation looks like this:
  - 0x100000 (1MB) to 0x200000 (2MB): all pages are allocated as regular 4KB pages, so 256 4KB pages.
  - 0x200000 to 0x600000: two super pages (2MBytes * 2)
  - 0x600000 to 0x60A000: about 10 regular 4KB pages

- Scenarios:
  - Scenario 1: both oldsz and newsz are within 0x600000 and 0x60A000, this means it's regular 4KB deallocation, so we just use the original method. Assuming newsz is at 0x603100.

  - Scenario 2: Now oldsz is PGROUNDUP(0x603100) = 0x604000, and newsz is 0x50A080, so we will need to first deallocate 4 regular pages, and then deallocate one super page. But we are deallocating too much, so we need to re-allocate regular pages from 0x400000 to PGROUNDUP(0x50A080) = 0x50B000.

  - Scenario 3: Now oldsz is 0x50B000, and newsz is 0x1FF0A0, PGROUNDUP(newsz) = 0x200000, so we want to deallocate regular pages till 0x400000, and then deallocate one super page.

- Algorithm:
  - 

```C
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    return oldsz;

  uint64 newszgu = PGROUNDUP(newsz);
  uint64 oldszgu = PGROUNDUP(oldsz);

  while (newszgu < oldszgu)
  {
    int found = 0;
    uint64 lowergu = oldszgu - 4096;
    for (; lowergu >= newszgu; lowergu -= 4096)
    {
      // findlowergu returns 1 for regular pages and 2 for super pages
      if (findlowergu(lowergu) > 0)
      {
        found = 1;
        break;
      }
    }
    /*
      NOTE: There is a possibility that there is no valid mapping, so we stop at newszgu and must create a new mapping
      e.g. we have a supaer page from 0x20000 to 0x40000, now we want to ummap 0x38F00 to 0x40000, we have no choice but to unmap the whole super page and then remap 0x20000 to 0x39000 to regular pages.
    */
    if (found == 1)
    {
      // Since VAs are contigous, I think this is just one 4K page, but let's do it the old way anyway
      int npages = (oldszgu - lowergu) / PGSIZE;
      uvmunmap(pagetable, lowergu, npages, 1);
      oldszgu = lowergu;
      // newszgu doesn't change as it has not been reached
    }
    else if (found == 2)
    {
      int nsuperpages  = (oldszgu - lowergu)  / SUPERPGSIZE;
      uvmunsupermap(pagetable, lowergu, nsuperpages, 1);
      oldszgu = lowergu;
      // newszgu doesn't change as it has not been reached
    }
    else if (found == 0)
    {
      // This means we are in the middle of a superpage, because if we are in a regular page, we should hit some PTE
      // We need to unmap the whole super page, and then remap (base, newszgu) into chunks of regular pages
      uvmunsupermap(pagetable, SUPERPGROUNDDOWN(newszgu), 1, 1);
      uvmalloc(pagetable, SUPERPGROUNDDOWN(newszgu), newszgu, PTE_V);
    }
  }

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
```